package com.sanju.systemx

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ScrollView
import com.sanju.systemx.shizuku.ShizukuBridge
import com.sanju.systemx.ui.*

class MainActivity : Activity() {
    private lateinit var status: android.widget.TextView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setPadding(dp(32), dp(24), dp(32), dp(24)); setBackgroundColor(C.BG)
        }
        col.addView(tv("SANJU", 38f, C.GREEN, true, true))
        col.addView(tv("SYSTEMX", 38f, C.WHITE, true))
        col.addView(tv("GAME SPACE", 14f, C.DIM, true), lp(WRAP, WRAP, t = dp(4)))
        status = tv("", 13f, C.DIM)
        col.addView(status, lp(WRAP, WRAP, t = dp(24), b = dp(24)))
        val open = chip("OPEN GAME SPACE", true).apply {
            textSize = 16f; setPadding(dp(32), dp(14), dp(32), dp(14))
            setOnClickListener { startActivity(Intent(this@MainActivity, GameSpaceActivity::class.java)) }
        }
        col.addView(open)
        setContentView(ScrollView(this).apply { isFillViewport = true; addView(col, MATCH, MATCH) })
    }

    override fun onResume() {
        super.onResume()
        val g = ShizukuBridge.granted()
        status.text = if (g) "● SHIZUKU CONNECTED" else "○ SHIZUKU NOT CONNECTED"
        status.setTextColor(if (g) C.GREEN else C.DIM)
    }
}
