package com.sanju.systemx.shizuku

import android.content.pm.PackageManager
import rikka.shizuku.Shizuku

class ShellResult(val code: Int, val out: String) {
    val ok: Boolean get() = code == 0 && !out.contains("Exception") &&
        !out.contains("Unknown command") && !out.contains("Error")
}

/** Every call is safe when Shizuku is missing/stopped: returns false/null. */
object ShizukuBridge {
    const val REQ = 4242

    fun running(): Boolean = try { Shizuku.pingBinder() } catch (t: Throwable) { false }

    fun granted(): Boolean = try {
        running() && !Shizuku.isPreV11() &&
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (t: Throwable) { false }

    fun requestPermission(): Boolean = try {
        if (running() && !granted()) { Shizuku.requestPermission(REQ); true } else false
    } catch (t: Throwable) { false }

    /** Runs a shell command (shell uid) through Shizuku. Blocking: call off the main thread. */
    fun run(cmd: String): ShellResult? {
        if (!granted()) return null
        return try {
            val m = Shizuku::class.java.getDeclaredMethod(
                "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java)
            m.isAccessible = true
            val p = m.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
            val out = p.inputStream.bufferedReader().readText()
            val err = p.errorStream.bufferedReader().readText()
            ShellResult(p.waitFor(), (out + err).trim())
        } catch (t: Throwable) {
            ShellResult(-1, t.message ?: "error")
        }
    }
}
