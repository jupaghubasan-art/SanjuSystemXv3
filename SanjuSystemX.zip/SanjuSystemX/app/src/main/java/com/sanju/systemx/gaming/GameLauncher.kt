package com.sanju.systemx.gaming

import android.content.Context
import android.content.Intent

object GameLauncher {
    fun launch(ctx: Context, pkg: String): Boolean = try {
        val i = ctx.packageManager.getLaunchIntentForPackage(pkg)
        if (i == null) false else { i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); ctx.startActivity(i); true }
    } catch (t: Throwable) { false }
}
