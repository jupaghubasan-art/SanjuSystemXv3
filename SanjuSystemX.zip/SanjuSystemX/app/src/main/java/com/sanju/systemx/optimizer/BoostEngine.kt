package com.sanju.systemx.optimizer

import android.app.ActivityManager
import android.content.pm.ApplicationInfo
import android.content.Context
import android.content.Intent
import android.provider.Settings
import com.sanju.systemx.shizuku.ShizukuBridge

class BoostResult(val applied: List<String>, val unavailable: List<String>)

/**
 * Real, reversible, non-root optimizations. Intensity:
 *  40%  - background cleanup via normal Android API (no Shizuku needed)
 *  60%  - + Shizuku: kill cached processes, per-game PERFORMANCE game mode, game app standby bucket ACTIVE
 *  80%  - + Shizuku: fixed performance mode (undone on boost off)
 *  100% - + Shizuku: dexopt (speed-profile compile) of the selected game, runs in background
 * Nothing is reported as applied unless the call actually succeeded.
 */
class BoostEngine(private val ctx: Context) {
    private var modePkg: String? = null
    private var fixedPerf = false
    private val safePkg = Regex("^[A-Za-z0-9._]+$")

    fun apply(level: Int, game: String?): BoostResult {
        val ok = mutableListOf<String>()
        val no = mutableListOf<String>()
        val pkg = game?.takeIf { safePkg.matches(it) }

        // --- 40%: background cleanup (normal API) ---
        try {
            val am = ctx.getSystemService(ActivityManager::class.java)
            val before = avail(am)
            val n = cleanBackground(am, pkg)
            Thread.sleep(500)
            val freedMb = (avail(am) - before) / (1024 * 1024)
            if (n > 0) ok += "Background cleanup requested for $n apps (available RAM change: ${if (freedMb >= 0) "+" else ""}$freedMb MB)"
            else no += "No background apps to clean"
        } catch (t: Throwable) { no += "Background cleanup unavailable" }

        if (level < 60) return BoostResult(ok, no)

        if (!ShizukuBridge.granted()) {
            no += "Deeper optimizations need Shizuku (NOT CONNECTED)"
            return BoostResult(ok, no)
        }

        // --- 60%: Shizuku ---
        run("am kill-all")?.let { if (it.ok) ok += "Cached background processes killed" else no += "Process cleanup unavailable" }
        if (pkg != null) {
            if (modePkg != null && modePkg != pkg) run("cmd game reset $modePkg")
            val r = run("cmd game mode performance $pkg")?.takeIf { it.ok } ?: run("cmd game set --mode 2 $pkg")
            if (r != null && r.ok) { modePkg = pkg; ok += "Game mode set to PERFORMANCE for selected game" }
            else no += "Game mode: NOT SUPPORTED ON THIS DEVICE"
            val b = run("am set-standby-bucket $pkg active")
            if (b != null && b.ok) ok += "Game app standby bucket set to ACTIVE" else no += "Standby bucket unavailable"
        } else no += "Select a game for per-game optimizations"

        if (level < 80) return BoostResult(ok, no)

        // --- 80%: fixed performance mode (reverted in stop()) ---
        val f = run("cmd power set-fixed-performance-mode-enabled true")
        if (f != null && f.ok) { fixedPerf = true; ok += "Fixed performance mode enabled" }
        else no += "Fixed performance mode: NOT SUPPORTED ON THIS DEVICE"

        if (level < 100) return BoostResult(ok, no)

        // --- 100%: dexopt the game in background ---
        if (pkg != null) {
            Thread { try { run("cmd package compile -m speed-profile -f $pkg") } catch (t: Throwable) { } }.start()
            ok += "Game code optimization requested (runs in background)"
        } else no += "Code optimization needs a selected game"
        return BoostResult(ok, no)
    }

    /** Undo what apply() changed. */
    fun stop() {
        try {
            if (fixedPerf) { run("cmd power set-fixed-performance-mode-enabled false"); fixedPerf = false }
            modePkg?.let { run("cmd game reset $it"); modePkg = null }
        } catch (t: Throwable) { }
    }

    private fun run(cmd: String) = ShizukuBridge.run(cmd)
    private fun avail(am: ActivityManager) = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }.availMem

    private fun cleanBackground(am: ActivityManager, game: String?): Int {
        val pm = ctx.packageManager
        val home = pm.resolveActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), 0)?.activityInfo?.packageName
        val ime = Settings.Secure.getString(ctx.contentResolver, "default_input_method")?.substringBefore('/')
        val skip = setOf(ctx.packageName, game, home, ime, "moe.shizuku.privileged.api")
        var n = 0
        for (a in pm.getInstalledApplications(0)) {
            if ((a.flags and ApplicationInfo.FLAG_SYSTEM) != 0 || a.packageName in skip) continue
            am.killBackgroundProcesses(a.packageName); n++
        }
        return n
    }
}
