package com.sanju.systemx.gaming

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.graphics.drawable.Drawable

class Game(val pkg: String, val name: String, val icon: Drawable)

class GameScanner(private val ctx: Context) {
    private val priority = "com.mobile.legends" // Mobile Legends: Bang Bang first, if installed
    private val known = setOf(
        priority, "com.tencent.ig", "com.pubg.imobile", "com.dts.freefireth", "com.dts.freefiremax",
        "com.activision.callofduty.shooter", "com.garena.game.codm", "com.miHoYo.GenshinImpact",
        "com.supercell.clashofclans", "com.supercell.brawlstars", "com.roblox.client"
    )

    @Suppress("DEPRECATION")
    fun scan(showAll: Boolean): List<Game> = try {
        val pm = ctx.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        pm.queryIntentActivities(intent, 0)
            .mapNotNull { ri ->
                val ai = ri.activityInfo.applicationInfo
                val pkg = ai.packageName
                if (pkg == ctx.packageName) return@mapNotNull null
                val isGame = ai.category == ApplicationInfo.CATEGORY_GAME ||
                    (ai.flags and ApplicationInfo.FLAG_IS_GAME) != 0 || pkg in known
                if (!isGame && !showAll) return@mapNotNull null
                Game(pkg, ri.loadLabel(pm).toString(), ri.loadIcon(pm))
            }
            .distinctBy { it.pkg }
            .sortedWith(compareBy({ it.pkg != priority }, { it.name.lowercase() }))
    } catch (t: Throwable) { emptyList() }
}
