package com.sanju.systemx.ui

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView

object C {
    val BG = Color.parseColor("#050805")
    val CARD = Color.parseColor("#0E1A12")
    val GREEN = Color.parseColor("#00FF88")
    val DARKGREEN = Color.parseColor("#0A3D26")
    val DIM = Color.parseColor("#7FA38C")
    val WHITE = Color.parseColor("#E8FFF0")
    val WARN = Color.parseColor("#FF5A5A")
}

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

fun Context.shape(fill: Int, stroke: Int, radiusDp: Int, strokeDp: Int = 1) = GradientDrawable().apply {
    setColor(fill); cornerRadius = dp(radiusDp).toFloat(); setStroke(dp(strokeDp), stroke)
}

fun Context.tv(t: String, sp: Float, color: Int, bold: Boolean = false, glow: Boolean = false) = TextView(this).apply {
    text = t; textSize = sp; setTextColor(color)
    if (bold) typeface = Typeface.DEFAULT_BOLD
    if (glow) setShadowLayer(dp(8).toFloat(), 0f, 0f, C.GREEN)
}

fun lp(w: Int, h: Int, wt: Float = 0f, l: Int = 0, t: Int = 0, r: Int = 0, b: Int = 0) =
    LinearLayout.LayoutParams(w, h, wt).apply { setMargins(l, t, r, b) }

const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

/** Pill-style chip/button used for tabs, boost levels, refresh rates. */
fun Context.chip(label: String, selected: Boolean): TextView = tv(label, 13f, if (selected) C.BG else C.GREEN, true).apply {
    gravity = android.view.Gravity.CENTER
    setPadding(dp(14), dp(8), dp(14), dp(8))
    background = shape(if (selected) C.GREEN else C.CARD, C.GREEN, 18)
}

fun View.styleChip(selected: Boolean, ctx: Context) {
    (this as TextView).setTextColor(if (selected) C.BG else C.GREEN)
    background = ctx.shape(if (selected) C.GREEN else C.CARD, C.GREEN, 18)
}
