package com.sanju.systemx.display

import android.content.Context
import android.hardware.display.DisplayManager
import android.view.Display
import com.sanju.systemx.shizuku.ShizukuBridge

class DisplayController(private val ctx: Context) {
    private fun d(): Display = ctx.getSystemService(DisplayManager::class.java).getDisplay(Display.DEFAULT_DISPLAY)

    fun current(): Int = try { Math.round(d().refreshRate) } catch (t: Throwable) { 0 }
    fun supported(): Set<Int> = try { d().supportedModes.map { Math.round(it.refreshRate) }.toSet() } catch (t: Throwable) { emptySet() }

    /** Blocking. Writes min/peak refresh settings via Shizuku, then verifies what the display reports. */
    fun setRate(hz: Int): String {
        if (!ShizukuBridge.granted()) return "UNAVAILABLE — requires Shizuku"
        if (hz !in supported()) return "NOT SUPPORTED ON THIS DEVICE"
        val r = ShizukuBridge.run("settings put system min_refresh_rate $hz && settings put system peak_refresh_rate $hz")
        if (r == null || !r.ok) return "OPTIMIZATION UNAVAILABLE"
        Thread.sleep(1200)
        val now = current()
        return if (now == hz) "Display now at $hz Hz"
        else "Setting written, but display reports $now Hz (this device may ignore it)"
    }

    fun reset(): String {
        if (!ShizukuBridge.granted()) return "UNAVAILABLE — requires Shizuku"
        val r = ShizukuBridge.run("settings delete system min_refresh_rate; settings delete system peak_refresh_rate")
        return if (r != null && r.code == 0) "Refresh rate back to device default" else "OPTIMIZATION UNAVAILABLE"
    }
}
