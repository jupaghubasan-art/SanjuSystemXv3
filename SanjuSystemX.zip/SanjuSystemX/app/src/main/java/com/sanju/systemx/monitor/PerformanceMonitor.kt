package com.sanju.systemx.monitor

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.display.DisplayManager
import android.os.BatteryManager
import android.os.Handler
import android.os.Looper
import android.view.Display
import com.sanju.systemx.shizuku.ShizukuBridge
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.TimeUnit

/** FPS is never faked: true per-game FPS isn't accessible to a normal app, so it stays "--". */
class Metrics(val fps: String = "--", val hz: String = "--", val cpu: String = "--",
              val ram: String = "--", val temp: String = "--")

class PerformanceMonitor(private val ctx: Context, private val onUpdate: (Metrics) -> Unit) {
    private var ex: ScheduledExecutorService? = null
    private val main = Handler(Looper.getMainLooper())
    private var lastTotal = 0L
    private var lastIdle = 0L

    fun start() {
        if (ex != null) return
        lastTotal = 0L
        ex = Executors.newSingleThreadScheduledExecutor().also {
            it.scheduleWithFixedDelay({
                try { val m = read(); main.post { onUpdate(m) } } catch (t: Throwable) { }
            }, 0, 2, TimeUnit.SECONDS)
        }
    }

    fun stop() { ex?.shutdownNow(); ex = null }

    private fun read() = Metrics(hz = hz(), cpu = cpu(), ram = ram(), temp = temp())

    private fun hz(): String = try {
        val d = ctx.getSystemService(DisplayManager::class.java).getDisplay(Display.DEFAULT_DISPLAY)
        Math.round(d.refreshRate).toString()
    } catch (t: Throwable) { "--" }

    private fun ram(): String = try {
        val mi = ActivityManager.MemoryInfo()
        ctx.getSystemService(ActivityManager::class.java).getMemoryInfo(mi)
        "${100 * (mi.totalMem - mi.availMem) / mi.totalMem}%"
    } catch (t: Throwable) { "--" }

    private fun temp(): String = try {
        val t = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            ?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1) ?: -1
        if (t <= 0) "--" else "%.0f°C".format(t / 10.0) // battery temperature
    } catch (t: Throwable) { "--" }

    /** /proc/stat is blocked for normal apps on Android 8+, so CPU needs Shizuku; otherwise "--". */
    private fun cpu(): String = try {
        val r = ShizukuBridge.run("head -n1 /proc/stat")
        if (r == null || !r.ok) "--" else {
            val p = r.out.split(Regex("\\s+")).drop(1).mapNotNull { it.toLongOrNull() }
            if (p.size < 5) "--" else {
                val idle = p[3] + p[4]
                val total = p.take(8).sum()
                val dT = total - lastTotal
                val dI = idle - lastIdle
                val res = if (lastTotal > 0 && dT > 0) "${100 * (dT - dI) / dT}%" else "--"
                lastTotal = total; lastIdle = idle
                res
            }
        }
    } catch (t: Throwable) { "--" }
}
