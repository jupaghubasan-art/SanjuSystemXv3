package com.sanju.systemx.settings

import android.content.Context

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("sanju_systemx", Context.MODE_PRIVATE)
    private fun b(k: String, d: Boolean) = sp.getBoolean(k, d)
    private fun s(k: String, v: Boolean) = sp.edit().putBoolean(k, v).apply()

    var sound: Boolean get() = b("sound", true); set(v) = s("sound", v)
    var haptic: Boolean get() = b("haptic", true); set(v) = s("haptic", v)
    var autoBoost: Boolean get() = b("autoBoost", false); set(v) = s("autoBoost", v)
    var anim: Boolean get() = b("anim", true); set(v) = s("anim", v)
    var monitor: Boolean get() = b("monitor", true); set(v) = s("monitor", v)
    var vivid: Boolean get() = b("vivid", false); set(v) = s("vivid", v)
    var cinematic: Boolean get() = b("cinematic", false); set(v) = s("cinematic", v)
    var contrast: Boolean get() = b("contrast", false); set(v) = s("contrast", v)
    var showAll: Boolean get() = b("showAll", false); set(v) = s("showAll", v)
    var boostLevel: Int
        get() = sp.getInt("boostLevel", 60)
        set(v) = sp.edit().putInt("boostLevel", v).apply()
}
