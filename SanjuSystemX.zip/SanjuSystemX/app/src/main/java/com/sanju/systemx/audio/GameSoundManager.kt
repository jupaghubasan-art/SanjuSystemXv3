package com.sanju.systemx.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.VibrationEffect
import android.os.Vibrator
import com.sanju.systemx.settings.Prefs
import java.util.concurrent.Executors
import kotlin.math.PI
import kotlin.math.sin

/** Original synthesized sound effects (no audio files, no copyrighted material) + light haptics. */
class GameSoundManager(ctx: Context, private val prefs: Prefs) {
    private val ex = Executors.newSingleThreadExecutor()
    private val vib: Vibrator? = try { ctx.getSystemService(Vibrator::class.java) } catch (t: Throwable) { null }
    private val sr = 22050

    // (startHz, endHz, durationMs); 0 Hz = silence
    private val sounds = mapOf(
        "open" to listOf(Triple(180, 700, 170), Triple(700, 1400, 130), Triple(1400, 1400, 90)),
        "click" to listOf(Triple(1300, 1300, 22)),
        "on" to listOf(Triple(600, 1000, 70)),
        "off" to listOf(Triple(1000, 500, 70)),
        "boost" to listOf(Triple(300, 1600, 230), Triple(1600, 1600, 70)),
        "launch" to listOf(Triple(500, 1900, 220), Triple(1900, 1900, 60)),
        "shizuku" to listOf(Triple(880, 880, 60), Triple(0, 0, 30), Triple(1320, 1320, 90)),
        "error" to listOf(Triple(320, 320, 120), Triple(0, 0, 30), Triple(220, 220, 170))
    )

    fun play(kind: String) {
        if (!prefs.sound) return
        val seq = sounds[kind] ?: return
        ex.execute { try { tone(seq) } catch (t: Throwable) { } }
    }

    fun haptic(strong: Boolean = false) {
        if (!prefs.haptic) return
        try { vib?.vibrate(VibrationEffect.createOneShot(if (strong) 35L else 14L, VibrationEffect.DEFAULT_AMPLITUDE)) }
        catch (t: Throwable) { }
    }

    private fun tone(seq: List<Triple<Int, Int, Int>>) {
        val data = ArrayList<Short>()
        var phase = 0.0
        for ((f0, f1, ms) in seq) {
            val n = sr * ms / 1000
            for (i in 0 until n) {
                val f = f0 + (f1 - f0) * i.toDouble() / n
                phase += 2 * PI * f / sr
                val edge = minOf(i, n - i, sr / 125).toDouble() / (sr / 125) // ~8ms fade in/out
                val amp = if (f0 == 0) 0.0 else 0.30 * edge
                data.add((sin(phase) * amp * Short.MAX_VALUE).toInt().toShort())
            }
        }
        val pcm = data.toShortArray()
        val track = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_GAME)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
            .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(sr).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setBufferSizeInBytes(pcm.size * 2)
            .setTransferMode(AudioTrack.MODE_STATIC).build()
        track.write(pcm, 0, pcm.size)
        track.play()
        Thread.sleep(pcm.size * 1000L / sr + 80)
        track.release()
    }
}
