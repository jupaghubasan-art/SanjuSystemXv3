package com.sanju.systemx

import android.app.Activity
import android.content.res.ColorStateList
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.media.AudioManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.*
import com.sanju.systemx.audio.GameSoundManager
import com.sanju.systemx.display.DisplayController
import com.sanju.systemx.gaming.Game
import com.sanju.systemx.gaming.GameLauncher
import com.sanju.systemx.gaming.GameScanner
import com.sanju.systemx.monitor.Metrics
import com.sanju.systemx.monitor.PerformanceMonitor
import com.sanju.systemx.optimizer.BoostEngine
import com.sanju.systemx.settings.Prefs
import com.sanju.systemx.shizuku.ShizukuBridge
import com.sanju.systemx.ui.*
import rikka.shizuku.Shizuku
import java.util.concurrent.Executors

class GameSpaceActivity : Activity() {
    private lateinit var prefs: Prefs
    private lateinit var sfx: GameSoundManager
    private lateinit var disp: DisplayController
    private lateinit var engine: BoostEngine
    private lateinit var monitor: PerformanceMonitor
    private val io = Executors.newSingleThreadExecutor()
    private val ui = Handler(Looper.getMainLooper())

    private var games = listOf<Game>()
    private var selected: String? = null
    private var boostActive = false
    private var lastGranted = false

    private lateinit var root: FrameLayout
    private lateinit var shizukuTv: TextView
    private lateinit var boostBtn: TextView
    private lateinit var boostInfo: TextView
    private lateinit var gamesRow: LinearLayout
    private lateinit var hzStatus: TextView
    private lateinit var host: FrameLayout
    private val metricTv = HashMap<String, TextView>()
    private val levelChips = HashMap<Int, TextView>()
    private val tabs = ArrayList<TextView>()
    private val pages = ArrayList<View>()

    private val onBinder = Shizuku.OnBinderReceivedListener { runOnUiThread { refreshShizuku(true) } }
    private val onDead = Shizuku.OnBinderDeadListener { runOnUiThread { refreshShizuku(false) } }
    private val onPerm = Shizuku.OnRequestPermissionResultListener { _, _ -> runOnUiThread { refreshShizuku(true) } }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        prefs = Prefs(this); sfx = GameSoundManager(this, prefs)
        disp = DisplayController(this); engine = BoostEngine(this)
        monitor = PerformanceMonitor(this) { m -> showMetrics(m) }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (Build.VERSION.SDK_INT >= 28)
            window.attributes.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        immersive()
        try {
            Shizuku.addBinderReceivedListenerSticky(onBinder)
            Shizuku.addBinderDeadListener(onDead)
            Shizuku.addRequestPermissionResultListener(onPerm)
        } catch (t: Throwable) { }
        setContentView(build())
        refreshShizuku(false)
        loadGames()
        applyVisuals()
        if (prefs.anim) intro() else sfx.play("open")
    }

    override fun onResume() { super.onResume(); immersive(); if (prefs.monitor) monitor.start() }
    override fun onPause() { super.onPause(); monitor.stop() } // no polling while a game is in front
    override fun onDestroy() {
        super.onDestroy(); monitor.stop()
        try {
            Shizuku.removeBinderReceivedListener(onBinder); Shizuku.removeBinderDeadListener(onDead)
            Shizuku.removeRequestPermissionResultListener(onPerm)
        } catch (t: Throwable) { }
    }

    @Suppress("DEPRECATION")
    private fun immersive() {
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
    }

    private fun View.press(kind: String = "click", f: () -> Unit) =
        setOnClickListener { sfx.play(kind); sfx.haptic(); f() }

    // ------------------------------------------------------------------ layout
    private fun build(): View {
        root = FrameLayout(this).apply { setBackgroundColor(C.BG) }
        val main = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(dp(28), dp(12), dp(28), dp(12)) }

        // LEFT: branding + shizuku + boost
        val left = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        left.addView(tv("SANJU SYSTEMX", 20f, C.GREEN, true, true))
        left.addView(tv("GAME SPACE  ·  SYSTEM READY", 11f, C.DIM, true))
        shizukuTv = tv("", 12f, C.DIM, true).apply {
            setPadding(dp(12), dp(8), dp(12), dp(8)); background = shape(C.CARD, C.DARKGREEN, 12)
            setOnClickListener { sfx.haptic(); onShizukuTap() }
        }
        left.addView(shizukuTv, lp(MATCH, WRAP, t = dp(10)))

        boostBtn = tv("BOOST READY", 20f, C.GREEN, true, true).apply {
            gravity = Gravity.CENTER; setPadding(dp(8), dp(16), dp(8), dp(16))
            background = shape(C.CARD, C.GREEN, 16, 2)
            setOnClickListener { sfx.haptic(true); toggleBoost() }
        }
        left.addView(boostBtn, lp(MATCH, WRAP, t = dp(10)))
        val chips = LinearLayout(this).apply { gravity = Gravity.CENTER }
        for (lv in listOf(40, 60, 80, 100)) {
            val c = chip("$lv%", prefs.boostLevel == lv)
            c.setOnClickListener {
                sfx.play("click"); sfx.haptic(); prefs.boostLevel = lv
                levelChips.forEach { (k, v) -> v.styleChip(k == lv, this) }
                if (boostActive) activateBoost(selected, quiet = true)
            }
            levelChips[lv] = c
            chips.addView(c, lp(WRAP, WRAP, l = dp(3), r = dp(3)))
        }
        left.addView(chips, lp(MATCH, WRAP, t = dp(8)))
        boostInfo = tv("Pick an intensity, then tap BOOST.", 11f, C.DIM)
        left.addView(ScrollView(this).apply { addView(boostInfo) }, lp(MATCH, 0, 1f, t = dp(8)))
        main.addView(left, lp(0, MATCH, 0.36f, r = dp(16)))

        // RIGHT: metrics + tabs + pages
        val right = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val metrics = LinearLayout(this).apply { background = shape(C.CARD, C.DARKGREEN, 14); setPadding(dp(6), dp(6), dp(6), dp(6)) }
        for (k in listOf("FPS", "HZ", "CPU", "RAM", "TEMP")) {
            val cell = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
            cell.addView(tv(k, 10f, C.DIM, true))
            val v = tv("--", 17f, C.GREEN, true, true); metricTv[k] = v; cell.addView(v)
            metrics.addView(cell, lp(0, WRAP, 1f))
        }
        right.addView(metrics, lp(MATCH, WRAP))

        val tabRow = LinearLayout(this)
        host = FrameLayout(this)
        pages.addAll(listOf(gamesPage(), displayPage(), settingsPage()))
        listOf("GAMES", "DISPLAY", "SETTINGS").forEachIndexed { i, name ->
            val t = chip(name, i == 0); t.setOnClickListener { sfx.play("click"); sfx.haptic(); selectTab(i) }
            tabs.add(t); tabRow.addView(t, lp(WRAP, WRAP, r = dp(6)))
        }
        right.addView(tabRow, lp(MATCH, WRAP, t = dp(8), b = dp(8)))
        right.addView(host, lp(MATCH, 0, 1f))
        selectTab(0)
        main.addView(right, lp(0, MATCH, 0.64f))

        root.addView(main, MATCH, MATCH)
        return root
    }

    private fun selectTab(i: Int) {
        host.removeAllViews(); host.addView(pages[i], MATCH, MATCH)
        tabs.forEachIndexed { k, t -> t.styleChip(k == i, this) }
    }

    private fun switchRow(label: String, sub: String, init: Boolean, onChange: (Boolean) -> Unit): View {
        val row = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL; setPadding(dp(14), dp(8), dp(14), dp(8))
            background = shape(C.CARD, C.DARKGREEN, 12)
        }
        val labels = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        labels.addView(tv(label, 13f, C.WHITE, true))
        if (sub.isNotEmpty()) labels.addView(tv(sub, 10f, C.DIM))
        row.addView(labels, lp(0, WRAP, 1f))
        val sw = Switch(this).apply {
            isChecked = init
            val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
            thumbTintList = ColorStateList(states, intArrayOf(C.GREEN, C.DIM))
            trackTintList = ColorStateList(states, intArrayOf(C.DARKGREEN, C.CARD))
            setOnCheckedChangeListener { _, on -> sfx.play(if (on) "on" else "off"); sfx.haptic(); onChange(on) }
        }
        row.addView(sw)
        return row
    }

    private fun vstack(vararg views: View): ScrollView {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        views.forEach { col.addView(it, lp(MATCH, WRAP, b = dp(6))) }
        return ScrollView(this).apply { addView(col) }
    }

    // ------------------------------------------------------------------ pages
    private fun gamesPage(): View {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        head.addView(tv("MY GAMES", 14f, C.GREEN, true, true), lp(0, WRAP, 1f))
        head.addView(tv("SHOW ALL APPS", 10f, C.DIM, true), lp(WRAP, WRAP, r = dp(6)))
        head.addView(Switch(this).apply {
            isChecked = prefs.showAll
            setOnCheckedChangeListener { _, on -> sfx.play(if (on) "on" else "off"); prefs.showAll = on; loadGames() }
        })
        col.addView(head, lp(MATCH, WRAP, b = dp(6)))
        gamesRow = LinearLayout(this)
        col.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(gamesRow) }, lp(MATCH, MATCH))
        return col
    }

    private fun loadGames() {
        io.execute {
            val list = GameScanner(this).scan(prefs.showAll)
            ui.post {
                games = list
                if (selected == null || list.none { it.pkg == selected }) selected = list.firstOrNull()?.pkg
                renderGames()
            }
        }
    }

    private fun renderGames() {
        gamesRow.removeAllViews()
        if (games.isEmpty()) {
            gamesRow.addView(tv("No games detected.\nTurn on SHOW ALL APPS to pick any app.", 12f, C.DIM)); return
        }
        for (g in games) {
            val sel = g.pkg == selected
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
                setPadding(dp(10), dp(12), dp(10), dp(10))
                background = shape(C.CARD, if (sel) C.GREEN else C.DARKGREEN, 16, if (sel) 2 else 1)
                setOnClickListener { sfx.play("click"); sfx.haptic(); selected = g.pkg; renderGames() }
            }
            card.addView(ImageView(this).apply { setImageDrawable(g.icon) }, lp(dp(52), dp(52)))
            card.addView(tv(g.name, 11f, C.WHITE, true).apply {
                maxLines = 2; ellipsize = android.text.TextUtils.TruncateAt.END; gravity = Gravity.CENTER
            }, lp(MATCH, dp(34), t = dp(6)))
            card.addView(chip("PLAY", true).apply { setOnClickListener { play(g) } }, lp(MATCH, WRAP, t = dp(4)))
            gamesRow.addView(card, lp(dp(120), WRAP, r = dp(10)))
        }
    }

    private fun displayPage(): View {
        val sup = disp.supported()
        hzStatus = tv("Current display rate: ${disp.current()} Hz", 11f, C.DIM)
        val hzRow = LinearLayout(this)
        for (hz in listOf(60, 90, 120)) {
            val c = chip("$hz Hz", false)
            if (hz !in sup) c.alpha = 0.35f
            c.setOnClickListener {
                sfx.play("click"); sfx.haptic()
                if (hz !in sup) { hzStatus.text = "$hz Hz: NOT SUPPORTED ON THIS DEVICE"; return@setOnClickListener }
                hzStatus.text = "Applying $hz Hz…"
                io.execute { val m = disp.setRate(hz); ui.post { hzStatus.text = m; sfx.play(if (m.startsWith("Display now")) "on" else "error") } }
            }
            hzRow.addView(c, lp(WRAP, WRAP, r = dp(6)))
        }
        hzRow.addView(chip("DEFAULT", false).apply {
            setOnClickListener {
                sfx.play("click"); sfx.haptic()
                io.execute { val m = disp.reset(); ui.post { hzStatus.text = m } }
            }
        })
        val refresh = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(10), dp(14), dp(10)); background = shape(C.CARD, C.DARKGREEN, 12)
        }
        refresh.addView(tv("REFRESH RATE", 12f, C.GREEN, true))
        refresh.addView(hzRow, lp(WRAP, WRAP, t = dp(6), b = dp(6)))
        refresh.addView(hzStatus)
        refresh.addView(tv("Changing the rate requires Shizuku; the result is verified, not assumed.", 10f, C.DIM))

        val dm = resources.displayMetrics
        val res = tv("RESOLUTION\nDEVICE DEFAULT (${dm.widthPixels}×${dm.heightPixels})\nAdvanced resolution control: unavailable on this build", 11f, C.DIM)
            .apply { setPadding(dp(14), dp(10), dp(14), dp(10)); background = shape(C.CARD, C.DARKGREEN, 12) }

        val am = getSystemService(AudioManager::class.java)
        val vol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(10), dp(14), dp(10)); background = shape(C.CARD, C.DARKGREEN, 12)
        }
        vol.addView(tv("MEDIA VOLUME", 12f, C.GREEN, true))
        vol.addView(SeekBar(this).apply {
            max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC); progress = am.getStreamVolume(AudioManager.STREAM_MUSIC)
            progressTintList = ColorStateList.valueOf(C.GREEN); thumbTintList = ColorStateList.valueOf(C.GREEN)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    if (fromUser) try { am.setStreamVolume(AudioManager.STREAM_MUSIC, p, 0) } catch (t: Throwable) { }
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        })

        return vstack(
            refresh, res, vol,
            tv("GAME VISUALS  (applied to Game Space UI only)", 11f, C.GREEN, true),
            switchRow("VIVID COLOR", "", prefs.vivid) { prefs.vivid = it; applyVisuals() },
            switchRow("CINEMATIC", "", prefs.cinematic) { prefs.cinematic = it; applyVisuals() },
            switchRow("CONTRAST", "", prefs.contrast) { prefs.contrast = it; applyVisuals() }
        )
    }

    private fun settingsPage(): View = vstack(
        switchRow("SOUND EFFECTS", "Game Space sounds", prefs.sound) { prefs.sound = it },
        switchRow("HAPTIC FEEDBACK", "Light vibration on buttons / boost / launch", prefs.haptic) { prefs.haptic = it },
        switchRow("AUTO BOOST", "Apply boost automatically when pressing PLAY", prefs.autoBoost) { prefs.autoBoost = it },
        switchRow("GAME SPACE ANIMATION", "Short startup animation", prefs.anim) { prefs.anim = it },
        switchRow("PERFORMANCE MONITOR", "Polls every 2 s while Game Space is open", prefs.monitor) {
            prefs.monitor = it; if (it) monitor.start() else { monitor.stop(); showMetrics(Metrics()) }
        },
        tv("Boost level is chosen with the 40/60/80/100% chips on the left.", 10f, C.DIM)
    )

    // ------------------------------------------------------------------ behaviour
    private fun showMetrics(m: Metrics) {
        metricTv["FPS"]?.text = m.fps; metricTv["HZ"]?.text = m.hz; metricTv["CPU"]?.text = m.cpu
        metricTv["RAM"]?.text = m.ram; metricTv["TEMP"]?.text = m.temp
    }

    private fun refreshShizuku(sound: Boolean) {
        val g = ShizukuBridge.granted()
        val r = ShizukuBridge.running()
        shizukuTv.text = if (g) "● SHIZUKU CONNECTED" else
            "○ SHIZUKU NOT CONNECTED" + if (r) "  (tap to grant)" else "  (tap to open Shizuku)"
        shizukuTv.setTextColor(if (g) C.GREEN else C.DIM)
        if (sound && g && !lastGranted) sfx.play("shizuku")
        lastGranted = g
    }

    private fun onShizukuTap() {
        when {
            ShizukuBridge.granted() -> refreshShizuku(false)
            ShizukuBridge.running() -> ShizukuBridge.requestPermission()
            else -> if (!GameLauncher.launch(this, "moe.shizuku.privileged.api"))
                Toast.makeText(this, "Shizuku is not installed", Toast.LENGTH_SHORT).show()
        }
    }

    private fun setBoostUi(active: Boolean, info: String) {
        boostActive = active
        boostBtn.text = if (active) "BOOST ACTIVE" else "BOOST READY"
        boostBtn.background = shape(if (active) C.DARKGREEN else C.CARD, C.GREEN, 16, 2)
        boostInfo.text = info
    }

    private fun toggleBoost() {
        if (boostActive) {
            sfx.play("off"); setBoostUi(false, "Boost stopped; temporary settings restored.")
            io.execute { engine.stop() }
        } else activateBoost(selected)
    }

    private fun activateBoost(pkg: String?, quiet: Boolean = false, then: (() -> Unit)? = null) {
        if (!quiet) sfx.play("boost")
        boostBtn.text = "APPLYING…"; boostBtn.isEnabled = false
        val level = prefs.boostLevel
        io.execute {
            val r = try { engine.apply(level, pkg) } catch (t: Throwable) { null }
            ui.post {
                boostBtn.isEnabled = true
                if (r == null || r.applied.isEmpty()) {
                    setBoostUi(false, "No optimization could be applied.\n" + (r?.unavailable?.joinToString("\n") { "✗ $it" } ?: "OPTIMIZATION UNAVAILABLE"))
                    sfx.play("error")
                } else {
                    val head = "Optimizations applied: ${r.applied.size}" +
                        if (r.unavailable.isNotEmpty()) "\nSome optimizations unavailable on this device." else ""
                    setBoostUi(true, head + "\n\n" + r.applied.joinToString("\n") { "✓ $it" } +
                        (if (r.unavailable.isNotEmpty()) "\n" + r.unavailable.joinToString("\n") { "✗ $it" } else ""))
                }
                then?.invoke()
            }
        }
    }

    private fun play(g: Game) {
        sfx.play("launch"); sfx.haptic(true); selected = g.pkg
        flash("LAUNCHING  " + g.name.uppercase())
        if (boostActive || prefs.autoBoost) activateBoost(g.pkg, quiet = true) { launch(g) }
        else ui.postDelayed({ launch(g) }, 450)
    }

    private fun launch(g: Game) {
        if (!GameLauncher.launch(this, g.pkg)) {
            sfx.play("error"); Toast.makeText(this, "Could not launch ${g.name}", Toast.LENGTH_SHORT).show()
        }
    }

    // ------------------------------------------------------------------ visuals / animations
    private fun applyVisuals() {
        val cm = ColorMatrix()
        if (prefs.vivid) cm.postConcat(ColorMatrix().apply { setSaturation(1.5f) })
        if (prefs.cinematic) {
            cm.postConcat(ColorMatrix().apply { setSaturation(0.85f) })
            cm.postConcat(ColorMatrix(floatArrayOf(1.05f, 0f, 0f, 0f, 0f, 0f, 1f, 0f, 0f, 0f, 0f, 0f, 1.08f, 0f, 6f, 0f, 0f, 0f, 1f, 0f)))
        }
        if (prefs.contrast) {
            val c = 1.25f; val t = (-0.5f * c + 0.5f) * 255f
            cm.postConcat(ColorMatrix(floatArrayOf(c, 0f, 0f, 0f, t, 0f, c, 0f, 0f, t, 0f, 0f, c, 0f, t, 0f, 0f, 0f, 1f, 0f)))
        }
        if (!prefs.vivid && !prefs.cinematic && !prefs.contrast) root.setLayerType(View.LAYER_TYPE_NONE, null)
        else root.setLayerType(View.LAYER_TYPE_HARDWARE, Paint().apply { colorFilter = ColorMatrixColorFilter(cm) })
    }

    private fun overlay(lines: List<Triple<String, Float, Int>>, holdMs: Long, fadeMs: Long) {
        val ov = FrameLayout(this).apply { setBackgroundColor(C.BG); isClickable = true }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        lines.forEach { (t, s, c) -> col.addView(tv(t, s, c, true, c == C.GREEN).apply { gravity = Gravity.CENTER }) }
        ov.addView(col, FrameLayout.LayoutParams(MATCH, MATCH))
        root.addView(ov, MATCH, MATCH)
        col.alpha = 0f; col.scaleX = 0.92f; col.scaleY = 0.92f
        col.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(fadeMs).withEndAction {
            ov.animate().alpha(0f).setStartDelay(holdMs).setDuration(fadeMs).withEndAction { root.removeView(ov) }.start()
        }.start()
    }

    private fun intro() {
        sfx.play("open")
        overlay(listOf(Triple("SANJU", 34f, C.GREEN), Triple("SYSTEMX", 34f, C.WHITE), Triple("GAME SPACE", 14f, C.DIM)), 300, 300)
    }

    private fun flash(text: String) = overlay(listOf(Triple(text, 18f, C.GREEN)), 150, 200)
}
