# SanjuSystemX — Sanju Game Space (Kotlin, package com.sanju.systemx)

## Build the APK
**Android Studio:** open this folder → Sync → Build > Build APK(s). 
**Command line (JDK 17 + Android SDK, ANDROID_HOME set):** `gradle wrapper --gradle-version 8.7` once, then `./gradlew assembleDebug`.
**No setup:** push this folder to a GitHub repo; the included Actions workflow builds it — download the artifact `SanjuSystemX-debug-apk`.
Output: `app/build/outputs/apk/debug/app-debug.apk`

## What is real
- Game list: launcher apps categorized as games (+ known titles; Mobile Legends first). "Show all apps" lists everything. PLAY uses the package's launch intent.
- Boost (needs no root): 40% background cleanup via ActivityManager (works without Shizuku). With Shizuku: 60% adds `am kill-all`, per-game PERFORMANCE game mode, standby bucket ACTIVE; 80% adds fixed performance mode (reverted when boost is turned off); 100% adds dexopt of the game. The panel lists exactly what succeeded/failed. Gains may be small and are not measured.
- Metrics: HZ (display), RAM (system), TEMP (battery). CPU only with Shizuku (/proc/stat). FPS is always "--" (not accessible to normal apps).
- Refresh rate: via Shizuku `settings put system min/peak_refresh_rate`, then verified against what the display reports. Many OEMs ignore it.
- Resolution: shown, not changed. Game Visuals toggles affect the Game Space UI only.
- Shizuku: all calls are guarded; app works fully without it.
